package com.realpage.pex;

import java.util.Calendar;
import java.util.Date;

public class Item {
	Date start;
	Date end;
	private String rate;

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getEnd() {
		return end;
	}

	public void setEnd(Date end) {
		this.end = end;
	}

	public int getDaysInPeriod() {

		Calendar st = Calendar.getInstance();
		st.setTime(start);

		Calendar e = Calendar.getInstance();
		e.setTime(end);

		int days = 0;
		while (st.before(e)) {
			days++;
			st.add(Calendar.DATE, 1);
		}
		return days;

	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}
}
