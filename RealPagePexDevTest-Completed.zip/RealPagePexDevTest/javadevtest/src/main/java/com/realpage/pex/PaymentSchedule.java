package com.realpage.pex;

import com.realpage.pex.Item;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class PaymentSchedule {

	List<Item> items;
	private int numberOfItems;
	private int numberOfMonthToAdd;
	private String rate;
	private String startDate;
	private String endDate;
	private String billingFreq;
	private String rateFrequency;
	private String totalCharge;
	private int months;

	public PaymentSchedule(String rate, String rateFrequency, String startDate, String endDate, String billingFreq)
			throws Exception {
		this.rate = rate;
		this.startDate = startDate;
		this.endDate = endDate;
		this.billingFreq = billingFreq;
		this.rateFrequency = rateFrequency;
		setValues();

	}


	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getBillingFreq() {
		return billingFreq;
	}

	public void setBillingFreq(String billingFreq) {
		this.billingFreq = billingFreq;
	}

	public List<Item> getItems() throws Exception {
		items = new ArrayList<Item>();
		SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy");
		Date startDte = formatter.parse(startDate);
		boolean isQuarterly = false;

		for (int i = 0; i < numberOfItems; i++) {
			Item it = new Item();
			int j = i;
			if (isQuarterly) {
				j = 3 * i;
			}

			Calendar cal = Calendar.getInstance();
			cal.setTime(startDte);
			Calendar cal2 = Calendar.getInstance();
			cal2.setTime(startDte);

			cal.add(Calendar.MONTH, j);
			cal2.add(Calendar.MONTH, j + numberOfMonthToAdd);

			Date stDte = cal.getTime();
			cal2.add(Calendar.DATE, -1);
			cal2.set(Calendar.HOUR_OF_DAY, 23);
			cal2.set(Calendar.MINUTE, 59);
			cal2.set(Calendar.SECOND, 59);
			Date eDte = cal2.getTime();

			it.setStart(stDte);
			it.setEnd(eDte);
			it.setRate(getCalculatedRate(rate, stDte, eDte, it));
			items.add(it);

			if (billingFreq.equals("Quarterly")) {
				isQuarterly = true;
			}

		}
		return items;
	}

	public String getTotalCharge() throws Exception {
		double charge = 0;

		List<Item> it = getItems();
		for (Item i : it) {

			String convertRate = i.getRate();

			charge += Double.parseDouble(convertRate);

		}

		totalCharge = String.format("%.2f", charge);

		return totalCharge;
	}

	public String getCalculatedRate(String rate, Date sDate, Date eDate, Item i) {

		double calcRate;

		int numberOfDays = i.getDaysInPeriod();

		if (rateFrequency.equalsIgnoreCase("Weekly") && numberOfDays > 0) {
			calcRate = (Double.parseDouble(rate) / 7) * numberOfDays;

		} else if (billingFreq.equalsIgnoreCase("Quarterly") && months > 0) {

			calcRate = Double.parseDouble(rate) * 3;

		} else {
			return rate;
		}

		return String.format("%.2f", calcRate);
	}
	public void setValues() throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy");
		Date startDte = formatter.parse(startDate);
		Date endDte = formatter.parse(endDate);
		Calendar st = Calendar.getInstance();
		st.setTime(startDte);
		Calendar e = Calendar.getInstance();
		e.setTime(endDte);

		while (st.before(e)) {
			months++;
			st.add(Calendar.MONTH, 1);
		}

		System.out.println();
		if (billingFreq.equals("Monthly")) {

			if (months > 12) {
				numberOfItems = 12;
			} else {
				numberOfItems = months;
			}
			numberOfMonthToAdd = 1;
		} else if (billingFreq.equals("Quarterly")) {
			numberOfItems = Math.round(months / 3);
			numberOfMonthToAdd = 3;
		}
		}

}
